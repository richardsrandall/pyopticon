# Load all of these widgets
from .. import generic_widget
from .omega_usb_utc_widget import *
from .valco_2_way_valve_widget import *
from .aalborg_dpc_widget import *
from .thorlabs_light_meter_widget import *
from .iot_relay_widget import *
from .sri_gc_fid_widget import *
from .picarro_crd_widget import *
from .mks_mfc_widget import *
from .mks_ftir_widget import *

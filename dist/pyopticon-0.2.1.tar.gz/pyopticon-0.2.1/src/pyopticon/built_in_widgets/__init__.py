from .title_widget import TitleWidget
from .spiciness_widget import SpicinessWidget

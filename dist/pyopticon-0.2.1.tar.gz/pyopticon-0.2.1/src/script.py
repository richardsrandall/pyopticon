schedule_delay('0:00:10')
schedule_action('Reactor Bypass Valve','Position Selection','Bypass Reactor',False)
schedule_delay('0:00:10')
schedule_action('Reactor Bypass Valve','Position Selection','Thru Reactor',False)
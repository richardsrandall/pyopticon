pyopticon package
===================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pyopticon._system
   pyopticon.built_in_widgets
   pyopticon.majumdar_lab_widgets
   pyopticon.utilities

Submodules
----------

.. toctree::
   :maxdepth: 4

   pyopticon.dashboard
   pyopticon.generic_serial_emulator
   pyopticon.generic_widget
   pyopticon.minimal_widget

Module contents
---------------

.. automodule:: pyopticon
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

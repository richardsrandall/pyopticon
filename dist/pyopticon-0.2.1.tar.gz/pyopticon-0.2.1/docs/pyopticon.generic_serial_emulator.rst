pyopticon.generic\_serial\_emulator module
============================================

.. automodule:: pyopticon.generic_serial_emulator
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

pyopticon.minimal\_widget module
==================================

.. automodule:: pyopticon.minimal_widget
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

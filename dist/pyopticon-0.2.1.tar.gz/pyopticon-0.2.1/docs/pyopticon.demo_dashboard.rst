pyopticon.demo\_dashboard module
==================================

.. automodule:: pyopticon.demo_dashboard
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

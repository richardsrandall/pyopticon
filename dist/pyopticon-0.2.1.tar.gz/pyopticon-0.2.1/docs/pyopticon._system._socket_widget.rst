pyopticon.\_system.\_socket\_widget module
==========================================

.. automodule:: pyopticon._system._socket_widget
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

pyopticon.majumdar\_lab\_widgets.omega\_usb\_utc\_widget module
=================================================================

.. automodule:: pyopticon.majumdar_lab_widgets.omega_usb_utc_widget
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

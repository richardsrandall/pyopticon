pyopticon.\_system.\_data\_logging\_widget module
===================================================

.. automodule:: pyopticon._system._data_logging_widget
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

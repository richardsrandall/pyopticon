pyopticon.majumdar\_lab\_widgets.aalborg\_dpc\_widget module
==============================================================

.. automodule:: pyopticon.majumdar_lab_widgets.aalborg_dpc_widget
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

pyopticon.dashboard module
============================

.. automodule:: pyopticon.dashboard
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

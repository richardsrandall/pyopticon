pyopticon.\_system.\_automation\_widget module
================================================

.. automodule:: pyopticon._system._automation_widget
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

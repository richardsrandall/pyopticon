pyopticon.\_system.\_serial\_widget module
============================================

.. automodule:: pyopticon._system._serial_widget
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

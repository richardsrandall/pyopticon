pyopticon.majumdar\_lab\_widgets.sri\_gc\_fid\_widget module
==============================================================

.. automodule:: pyopticon.majumdar_lab_widgets.sri_gc_fid_widget
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

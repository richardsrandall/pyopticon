pyopticon.generic\_widget module
==================================

.. automodule:: pyopticon.generic_widget
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

pyopticon.built\_in\_widgets.spiciness\_widget module
=======================================================

.. automodule:: pyopticon.built_in_widgets.spiciness_widget
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

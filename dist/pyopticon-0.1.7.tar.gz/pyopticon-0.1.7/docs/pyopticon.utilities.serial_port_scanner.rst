pyopticon.utilities.serial\_port\_scanner module
==================================================

.. automodule:: pyopticon.utilities.serial_port_scanner
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

pyopticon.majumdar\_lab\_widgets.mks\_mfc\_widget module
==========================================================

.. automodule:: pyopticon.majumdar_lab_widgets.mks_mfc_widget
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

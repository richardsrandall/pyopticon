pyopticon.built\_in\_widgets package
======================================

Submodules
----------

.. toctree::
   :maxdepth: 4

   pyopticon.built_in_widgets.spiciness_widget
   pyopticon.built_in_widgets.title_widget

Module contents
---------------

.. automodule:: pyopticon.built_in_widgets
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

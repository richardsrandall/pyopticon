# Load all of these widgets
from .. import generic_widget
from .. import generic_serial_emulator
from .aalborg_dpc_widget import *
from .mks_mfc_widget import *
from .omega_usb_utc_widget import *
from .picarro_crd_widget import *
from .iot_relay_widget import *
from .valco_2_way_valve_widget import *
from .valco_8_way_valve_widget import *
from .sri_gc_fid_widget import *
from .cellkraft_humidifier_widget import *

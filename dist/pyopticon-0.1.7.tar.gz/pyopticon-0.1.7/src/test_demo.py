from pyopticon import demo_dashboard as dd
dd.run_demo_dashboard()
